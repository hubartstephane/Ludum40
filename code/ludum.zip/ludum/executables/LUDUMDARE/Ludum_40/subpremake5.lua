-- =============================================================================
-- ROOT_PATH/executables/GLFW/TestGLFW_CubeMap
-- =============================================================================

  WindowedApp()
  DependOnLib("CHAOS")
  DeclareResource("resources")    
    

                       