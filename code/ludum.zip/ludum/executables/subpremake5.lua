-- =============================================================================
-- ROOT_PATH/executables
-- =============================================================================

local BASE_GROUP = CURRENT_GROUP

CURRENT_GROUP = BASE_GROUP .. "/LUDUMDARE"
ProcessSubPremake("LUDUMDARE")
