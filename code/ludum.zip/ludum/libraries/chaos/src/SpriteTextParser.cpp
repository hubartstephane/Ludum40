#include <chaos/SpriteTextParser.h>
#include <chaos/MathTools.h>

namespace chaos
{

	namespace SpriteText
	{

	}; // namespace SpriteText
};